<?php

 $_USERS = array (
  0 => 
  array (
    'name' => 'admin',
    'pass' => '$1$KKPiGbfU$qhFNOMBw541VWaUV4ZOcs1',
    'role' => 'superadmin',
  ),
);
